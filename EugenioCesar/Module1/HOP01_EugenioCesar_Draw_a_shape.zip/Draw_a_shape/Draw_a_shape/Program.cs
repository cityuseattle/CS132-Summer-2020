﻿using System;

/********
**
** Name: Cesar, Eugenio
** Class: CS 132
** Project: Draw a Shape
** Date: 2020-07-19
** Description: Draw a shape
**
********/


namespace Draw_a_shape
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("     /|");
            Console.WriteLine("    / |");
            Console.WriteLine("   /  |");
            Console.WriteLine("  /   |");
            Console.WriteLine(" /____|");
        }
    }
}