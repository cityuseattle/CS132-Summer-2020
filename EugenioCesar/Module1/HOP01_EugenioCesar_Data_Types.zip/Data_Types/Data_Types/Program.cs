﻿using System;

namespace Data_Types

/********
**
** Name: Cesar, Eugenio
** Class: CS 132
** Project: xx
** Date: 2020-07-07
** Description: Data types.
**
********/

{
    class Program

    {
        static void Main(string[] args)

        {
            string Name = "Eugenio";
            int Age = 41;
            bool isMale = true;
         

            Console.WriteLine(Name);
            Console.WriteLine(Age);
            Console.WriteLine(isMale);
            
        }
    }
}